(function() {
    console.log('running')

    chrome.storage.sync.get(
        'pendingData', (data) => {
            //let temp = {...data.pendingData[0]}
            // console.log(data.pendingData)
            if (data.pendingData && data.pendingData.length > 0) {
                if (data.pendingData[0]['status'] && data.pendingData[0]['status'].toLowerCase() == 'update') {
                    updateReservation(data.pendingData[0], data.pendingData.length - 1)
                } else if (data.pendingData[0]['status'] && data.pendingData[0]['status'].toLowerCase() == 'cancel') {
                    cancelReservation(data.pendingData[0])
                } else {
                    newReservation(data.pendingData[0])
                }
            }

        })
    // console.log('running page-code.js')
})();

function updateReservation(reservation, toFollow) {
    document.querySelector('#existing-rez a').click()
    if (reservation['unit'][0] == '2') {
        // tresor
        document.querySelector('#contact-1 #tower_tresor').click()
    } else {
        // sorrento
        document.querySelector('#contact-1 #tower_sorrento').click()
    }

    document.querySelector('#contact-1 #unit_numbers').value = reservation['unit']
    document.querySelector('#contact-1 #confirmation_number').value = reservation['confirmation']

    document.querySelector('#contact-1 #owner_email').value = reservation['email'] ? reservation['email'] : 'benichaybrothers@gmail.com'

    document.querySelector('#contact-1 #first_name').value = reservation['fname']
    document.querySelector('#contact-1 #last_name').value = reservation['lname']

    let checkIn = reservation['checkin'].split('/').map(x => x.length == 1 ? '0' + x : x).join('/')
    let checkOut = reservation['checkout'].split('/').map(x => x.length == 1 ? '0' + x : x).join('/')

    document.querySelector('#contact-1 #requests').value = `Change check in to ${checkIn} - ${checkOut}. ${toFollow > 0 ? toFollow + ' reservation' + (toFollow > 1 ? 's' : '') + ' to follow.' : '' } `

}

function cancelReservation(reservation) {
    document.querySelector('#cancel-rez a').click()
    if (reservation['unit'][0] == '2') {
        // tresor
        document.querySelector('#contact #tower_tresor').click()
    } else {
        // sorrento
        document.querySelector('#contact #tower_sorrento').click()
    }

    document.querySelector('#contact #unit_numbers').value = reservation['unit']
    document.querySelector('#contact #confirmation_number').value = reservation['confirmation']

    document.querySelector('#contact #owner_email').value = reservation['email'] ? reservation['email'] : 'benichaybrothers@gmail.com'

    document.querySelector('#contact #guest_first_name').value = reservation['fname']
    document.querySelector('#contact #guest_last_name').value = reservation['lname']
}

function newReservation(reservation) {
    document.querySelector('#new-rez a').click()
    if (reservation['unit'][0] == '2') {
        // tresor
        document.querySelector('#new-rez #tower_tresor').click()
    } else {
        // sorrento
        document.querySelector('#new-rez #tower_sorrento').click()
    }

    document.querySelector('#new-rez #unit_numbers').value = reservation['unit']

    document.querySelector('#new-rez #owner_first_name').value = reservation['ownerfname']
    document.querySelector('#new-rez #owner_last_name').value = reservation['ownerlname']

    document.querySelector('#new-rez #owner_email').value = 'benichaybrothers@gmail.com'

    let checkIn = reservation['checkin'].split('/').map(x => x.length == 1 ? '0' + x : x).join('/')
    document.querySelector('#new-rez #arrival-date').value = checkIn
    document.querySelector('#new-rez [name="arrival-date_submit"]').value = checkIn

    let checkOut = reservation['checkout'].split('/').map(x => x.length == 1 ? '0' + x : x).join('/')
    document.querySelector('#new-rez #departure-date').value = checkOut
    document.querySelector('#new-rez [name="departure-date_submit"]').value = checkOut

    document.querySelector('#new-rez #arrival_time').value = '4:00 PM'
    document.querySelector('#new-rez [name="arrival_time_submit"]').value = '16:00:00'

    document.querySelector('#new-rez #guest_relation').value = 'Guest'

    document.querySelector('#new-rez #guest_first_name').value = reservation['fname']
    document.querySelector('#new-rez #guest_last_name').value = reservation['lname']

    document.querySelector('#new-rez #guest_email').value = reservation['email'] ? reservation['email'] : 'benichaybrothers@gmail.com'
    document.querySelector('#new-rez #guest_telephone').value = reservation['phone'] ? reservation['phone'] : '7862441933'
    // document.querySelector('#new-rez #guest_telephone').value = reservation['phone'] ? reservation['phone'] : '3053216425'

    document.querySelector('#new-rez #number_guests').value = reservation['people']

    document.querySelector('#new-rez #accompanying_guest_names').value = 'na'
    document.querySelector('#new-rez #lapis_guest_name_1').value = 'na'
    document.querySelector('#new-rez #lapis_guest_name_2').value = 'na'

    document.querySelector('#new-rez #daily_housekeeping_no').click()
    document.querySelector('#new-rez #every_other_day_housekeeping_no').click()
    document.querySelector('#new-rez #checkout_housekeeping_yes').click()
    document.querySelector('#new-rez #rollaway_no').click()

    document.querySelector('#new-rez #unit_owner_signature').value = reservation['email'] && reservation['email'] !== 'benichaybrothers@gmail.com' ?  reservation['ownerfname'] + ' ' + reservation['ownerlname'] : 'Ygal Benichay'
}
