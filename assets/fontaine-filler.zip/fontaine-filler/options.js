const fields = [
    'unit', 'confirmation', 'status', 'fname', 'lname', 'checkin', 'checkout', 'nights',
    'ownerfname', 'ownerlname', 'cleaning', 'people', 'spa', 'email', 'phone'
]

const baseUrl = 'https://brocko-lee.benichaybrothers.com/api/'
// const baseUrl = 'https://bcalserver.herokuapp.com/'
// const baseUrl = 'localhost:3000/'

var tokenValue = null

var loginForm = document.getElementById('bclient-login-form')
let loginBtn = document.getElementById('login-btn')

var dateForm = document.getElementById('date-range-picker')
var getBookingsBtn = document.getElementById('get-bookings-btn')

// BEGIN LEGACY CODE ///////////////////////////////////////////////////////////
let loadDataBtn = document.getElementById('load-data')
let refreshDataBtn = document.getElementById('refresh-data')

function showData() {
    let dataDiv = document.getElementById('data-div')
    let previousDataDiv = document.getElementById('previous-data-div')
    dataDiv.innerHTML = '<h3>Pending Entries:</h3>'
    previousDataDiv.innerHTML = '<h3>Entered Entries:</h3>'
    chrome.storage.sync.get(
        ['pendingData', 'previousData'],
        function (data) {
            console.log(data)
            if (data.pendingData && data.pendingData.length > 0 && data.pendingData[0].unit) {
                data.pendingData.forEach(x => {
                    addEntry(dataDiv, x)
                })
            } else {
                dataDiv.innerHTML += 'no data available, please load'
            }

            if (data.previousData && data.previousData.length > 0 && data.previousData[0].unit) {
                data.previousData.forEach(x => {
                    addEntry(previousDataDiv, x)
                })
            } else {
                previousDataDiv.innerHTML += 'no previous data has been submitted yet.'
            }
        })
}

function addEntry(element, entryData) {
    element.innerHTML += `
        Unit: ${entryData.unit}<br>
        Status: ${entryData.status}<br>
        Guest: ${entryData.fname + ' ' + entryData.lname}<br>
        Stay: ${entryData.checkin + ' - ' + entryData.checkout}<br>
        People: ${entryData.people}<br><br>
    `
}

function populateData() {
    let pendingData = document.getElementById('new-bookings').value.split('\n').map(x => {
        x = x.split('\t')
        let temp = {}
        x.map((y, i) => {
            if (fields[i]) {
                temp[fields[i]] = y
            }
        })
        if (temp['lname'] == '') {
            let name = temp['fname'].split(' ')
            let fName = name.shift()
            let lName = name.join(' ')
            temp['fname'] = fName
            temp['lname'] = lName
        }
        return temp
    })
    pendingData = pendingData.sort((x, y) => {
        if (x['status'].toLowerCase() == 'update') return -1
        if (y['status'].toLowerCase() == 'update') return 1
        return 0
    }).filter(x => x['fname'] && x['fname'].toLowerCase() != 'hotel')
    chrome.storage.sync.set({
        pendingData: [...pendingData],
        previousData: []
    }, function () {
        // console.log('data has been added to storage')
        document.getElementById('new-bookings').value = ''
        showData()
    })
}
// END LEGACY CODE /////////////////////////////////////////////////////////////

// BEGIN EXPERIMENTAL STUFF ////////////////////////////////////////////////////

function postData(url = '', data = {}) {
    // Default options are marked with *
    return fetch(url, {
        method: 'POST', // *GET, POST, PUT, DELETE, etc.
        // mode: 'cors', // no-cors, cors, *same-origin
        // cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
        // credentials: 'same-origin', // include, *same-origin, omit
        headers: {
            'Content-Type': 'application/json',
            // 'Content-Type': 'application/x-www-form-urlencoded',
        },
        // redirect: 'follow', // manual, *follow, error
        // referrer: 'no-referrer', // no-referrer, *client
        body: JSON.stringify(data), // body data type must match "Content-Type" header
    })
        .then(response => response.json()); // parses JSON response into native JavaScript objects
}

function checkToken(callback) {
    chrome.storage.sync.get(
        ['credentials'],
        (data) => {
            console.log(data)
            tokenValue = data.credentials.token
            if (tokenValue != null && tokenValue.length > 0) {
                loginForm.style.display = 'none'
                dateForm.style.display = 'block'
                callback(tokenValue)
            } else {
                loginForm.style.display = 'block'
                dateForm.style.display = 'none'
            }
        })
}

function initializeExtension() {
    checkToken((tokenData) => {
        console.log('call back called')
        console.log(tokenData)
        const propertiesEndpoint = baseUrl + 'properties/my-properties?token=' + tokenData

        // fetch(baseUrl + 'properties/my-properties?token=' + tokenData)

        postData(propertiesEndpoint, { pagination: {} }).then((response) => response.json()).then((propertyData) => {
            console.log('getting propertyData')
            console.log(propertyData)
            if (propertyData.error) {
                console.log('there was an error')
                tokenValue = null
                checkToken(() => { })
            } else {
                console.log('property data loded successfully')
            }
        }).catch((err) => {
            console.log('there was a problem')
            console.log(err)
        })
    })
}
// END EXPERIMENTAL STUFF //////////////////////////////////////////////////////




// BEGIN EVENT LISTENERS ///////////////////////////////////////////////////////
loadDataBtn.addEventListener('click', function () {
    populateData()
})

refreshDataBtn.addEventListener('click', function () {
    showData()
})

loginBtn.addEventListener('click', function () {
    let username = document.getElementById('bclient-username')
    let password = document.getElementById('bclient-password')
    postData(baseUrl + 'users/login', {
        username: username.value,
        password: password.value,
        rememberMe: true
    }).then((data) => {
        console.log(data)
        chrome.storage.sync.set({
            credentials: {
                username: data.user.username,
                token: data.token
            }
        }, function () {
            console.log('token data set')
            initializeExtension()
        })
    }).catch((err) => {
        console.log('there was an error')
        console.log(err)
    })
})

getBookingsBtn.addEventListener('click', function () {
    let startDate = document.getElementById('start-date')
    let endDate = document.getElementById('end-date')
    // postData(baseUrl + 'bookings/query-bookings?token=' + tokenValue, {
    postData(baseUrl + 'bookings/find?token=' + tokenValue, {
        bookingsQuery: {
            checkIn: startDate.value,
            checkOut: endDate.value
        },
        pagination: {
            page: 1,
            limit: 100
        }
    }).then((data) => {
        console.log(data)
    })
})

// END EVENT LISTENERS /////////////////////////////////////////////////////////

showData()

initializeExtension()
