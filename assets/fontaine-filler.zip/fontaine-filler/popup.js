let fillOutForm = document.getElementById('fill-form-btn');
let nextEntry = document.getElementById('next-entry')
let previousEntry = document.getElementById('previous-entry')
let entriesButton = document.getElementById('entries-button')

console.log('popupscript running')

chrome.storage.sync.get('pendingData', function(data) {
    showCurrentEntry(data.pendingData[0])
})

async function getCurrentTab() {
  let queryOptions = { active: true, lastFocusedWindow: true };
  // `tab` will either be a `tabs.Tab` instance or `undefined`.
  let [tab] = await chrome.tabs.query(queryOptions);
  return tab;
}

fillOutForm.onclick = async function(element) {
    let tab = await getCurrentTab()

  chrome.scripting.executeScript({
    target: {tabId: tab.id},
    files: ['page-code.js']
  });
}

nextEntry.onclick = function(element) {
    chrome.storage.sync.get(['pendingData', 'previousData'], function(data) {
        let temp = [...data.pendingData]
        let usedEntry = temp.shift()
        chrome.storage.sync.set({
            pendingData: [...temp],
            previousData: [...data.previousData, usedEntry]
        }, function() {
            // console.log('moving to next entry')
            showCurrentEntry(temp[0])
        })
    })
}

entriesButton.onclick = function(element) {
    chrome.runtime.openOptionsPage(function(data) {
        // console.log(data)
        // console.log('opening options page')
    })
}


previousEntry.onclick = function(element) {
    chrome.storage.sync.get(['pendingData', 'previousData'], function(data) {
        let temp = [...data.previousData]
        if (temp.length > 0) {
            let lastEntry = temp.pop()
            chrome.storage.sync.set({
                pendingData: [lastEntry, ...data.pendingData],
                previousData: [...temp]
            }, function() {
                // console.log('going back an entry')
                showCurrentEntry(lastEntry)
            })
        }
    })
}


function showCurrentEntry(entry) {
    let currentEntry = document.getElementById('current-entry')
    if (entry && entry.unit) {
        currentEntry.innerHTML = `
            unit: ${entry.unit} <br>
            confirmation: ${entry.confirmation} <br>
            status: ${entry.status} <br>
            name: ${entry.fname}  ${entry.lname} <br>
            dates: ${entry.checkin} - ${entry.checkout} <br><br>
        `
    } else {
        currentEntry.innerHTML = '<b>No more entries</b><br> Please click entries below to add more <br><br>'
    }

}
