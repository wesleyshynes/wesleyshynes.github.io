// https://fontainebleau.com/owners/miami-condo-reservation-request
chrome.runtime.onInstalled.addListener(function() {

    chrome.storage.sync.set({
        pendingData: [],
        previousData: [],
        credentials: {
            username: '',
            token: ''
        },
        properties: []
    }, function() {
        // console.log('Fontaine Filler Installed')
    });

    chrome.action.disable();

    chrome.declarativeContent.onPageChanged.removeRules(undefined, function() {
        chrome.declarativeContent.onPageChanged.addRules([{
            conditions: [new chrome.declarativeContent.PageStateMatcher({
                // pageUrl: {
                //     hostEquals: 'www.fontainebleau.com'
                // },
                pageUrl: { hostSuffix: '.fontainebleau.com', schemes: ['https'] },
            })],
            actions: [new chrome.declarativeContent.ShowPageAction()]
        }]);
    });

});
